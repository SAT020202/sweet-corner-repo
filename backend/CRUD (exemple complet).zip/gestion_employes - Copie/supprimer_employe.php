<?php
require 'db.php';
$id = intval($_GET['id']);
$query = "DELETE FROM employes WHERE id = ?";
$stmt = $pdo->prepare($query);
$stmt->execute([$id]);
//redirection vers la page index.php
header('Location: index.php');
exit();
?>