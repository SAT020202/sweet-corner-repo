<!DOCTYPE html>
<head>
    <title>Gestion des employers</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/styles.css">
    <link rel="icon" type="png" href="assets/logo.png">

</head>
<body>
    <h1>Gestion des Employés</h1>
    <br>
    <a href="ajout_employe.php"  class="btn btn-outline-success">Ajouter un employé</a> 
    <br><br>
    <table class="table table-striped">
    <?php
    require 'db.php';//include

    // Requête SQL pour récupérer tous les employés
    $query = "SELECT * FROM employes";
    $stmt = $pdo->query($query);

    // Récupérer les résultats sous forme de tableau associatif
    $employes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    ?>
  <thead>
    <tr>
      <th >Nom</th>
      <th >Age</th>
      <th >Ville</th>
      <th >Avatar</th>
      <th >Actions</th>

    </tr>
  </thead>
  <tbody>
  <?php foreach ($employes as $emp): ?>
        <tr>
            <td><?php echo htmlspecialchars($emp['nom']); ?></td>
            <td><?php echo htmlspecialchars($emp['ville']); ?></td>
            <td><?php echo htmlspecialchars($emp['age']); ?></td>
            <td><img src= uploads/<?php echo htmlspecialchars($emp['avatar']); ?>></td>
            <td><a href="modifier_employe.php?id=<?php echo $emp['id']; ?>" 
            class="btn btn-outline-warning">Modifier</a> 
            <a href="supprimer_employe.php?id=<?php echo $emp['id']; ?>" 
             onclick="return confirm('Voulez-vous vraiment supprimer cet employé ?');"
             class="btn btn-outline-danger">Supprimer</a></td>
        </tr>
    <?php endforeach; ?>

  </tbody>
</table>
</body>
</html>


