<?php
    require 'db.php';
    // Vérifier si le formulaire a été soumis
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Récupérer les données du formulaire
        $nom = htmlspecialchars($_POST['name']);
        $ville = htmlspecialchars($_POST['city']);
        $age = intval($_POST['age']);
        $avatar = $_FILES['avatar'];

        // Gestion de l'upload de l'image
        $target_file = basename($avatar['name']);

        // Vérifier si le fichier est une image valide
        $allowed_types = ['jpg', 'jpeg', 'png'];
        $image_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        //if $image_type is not in array allowed_types  
        if (!in_array($image_type, $allowed_types)) {
            die("Erreur : Seuls les fichiers JPG, JPEG, et PNG sont autorisés."); }

        try {
            $stmt = $pdo->prepare("INSERT INTO employes (nom, ville, age, avatar) VALUES (?, ?, ?, ?)");
            $stmt->execute([$nom, $ville, $age, $target_file]);

            $query = "SELECT max(id) FROM employes";
            $stmt = $pdo->query($query);
            $maxId = $stmt->fetchColumn();

            echo "<script>alert('Employé numéro $maxId ajouté avec succès.');</script>";
        } catch (Exception $e) {
            echo "Erreur lors de l'ajout de l'employé : " . $e->getMessage();
        }
        /*
        // Redirection vers la page principale
        header('Location: index.php');
        exit();*/
    }

?>



<!DOCTYPE html>
<head>
   <title>Gestion des employers</title>
   <link rel="stylesheet" href="css/bootstrap.min.css">
   <link rel="stylesheet" href="assets/styles.css">
  
</head>
<body>
    <div class="form-body">
        <div class="form-container">
            <form method="POST" enctype="multipart/form-data">
                <h1>Ajouter un employé</h1>
                <label for="nom">Nom :</label><br>
                <input type="text" id="name" name="name" class="form-control"><br>
                <label for="ville">Ville :</label><br>
                <input type="text" id="city" name="city" class="form-control"><br>
                <label for="age">Age :</label><br>
                <input type="number" id="age" name="age" class="form-control"><br>
                <input type="file" id='avatar' name="avatar"><br><br>
                <button type="submit"  class="d-grid gap-2 col-12 mx-auto btn btn-success">Ajouter</button><!--sans div-->
                <div class="text-center mt-3">
                    <a href="index.php" class="btn btn-secondary">Retour</a><!--avec div-->
                </div>
            </form>
        </div>
    </div>
</body>
</html>
