<!DOCTYPE html>
<html lang="en">
<head>
    <title>Gestion des employers</title>
   <link rel="stylesheet" href="css/bootstrap.min.css">
   <link rel="stylesheet" href="assets/styles.css"></head>
<body>
<div class="form-body">
    <div class="form-container">
        <form>
            <b><i><h2 align="center" color="blue">Se connecter</h2></i></b>
            <label for="inputEmail3" class="col-sm-2 col-form-label">Email</label>
            <input type="email" class="form-control" id="inputEmail3">
            <label for="inputPassword3" class="col-sm-2 col-form-label">Password</label>
            <input type="password" class="form-control" id="inputPassword3"><br>
            <a href="index.php" class="d-grid btn btn-info">Login</a>
        </form>
    </div>
</div>

</body>
</html>
