<?php
require 'db.php';

    $id = intval($_GET['id']); // Convertir l'ID en entier pour éviter les injections SQL

    // Requête pour récupérer les données de l'employé
    $query = "SELECT * FROM employes WHERE id = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$id]);
    $employe = $stmt->fetch(PDO::FETCH_ASSOC);


    // Extraire les données de l'employé
    $nom = htmlspecialchars($employe['nom']);
    $ville = htmlspecialchars($employe['ville']);
    $age = intval($employe['age']);
    $avatar_actuel = htmlspecialchars($employe['avatar']);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Récupérer les données du formulaire
        $n = htmlspecialchars($_POST['name']);
        $v = htmlspecialchars($_POST['city']);
        $a = intval($_POST['age']);
        

        // Gestion de l'upload de l'image
        $avatar = $_FILES['avatar'];
        $target_file = basename($avatar['name']);

        if ($target_file) {
            // Nouvel avatar téléchargé
            $query = "UPDATE employes SET nom = ?, ville = ?, age = ?, avatar = ? WHERE id = ?";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$n, $v, $a, $target_file,$id]);
        } else {
            // Aucun nouvel avatar téléchargé
            $query = "UPDATE employes SET nom = ?, ville = ?, age = ? WHERE id = ?";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$n, $v, $a,$id]);
        }
        //echo "<script>alert('Employé modifié avec succès.');</script>";
        header('Location: index.php');
        exit();
    }


?>

<!DOCTYPE html>
<head>
    <title>Modifier Employé</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/styles.css">
</head>
<body>
    <div class="form-body">
        <div class="form-container">
            <form method="POST" enctype="multipart/form-data">
                <h2>Modifier un employé</h2>
                <label for="nom">Nom :</label><br>
                <input type="text" id="name" name="name" value="<?php echo $nom; ?>" class="form-control"><br>
                <label for="ville">Ville :</label><br>
                <input type="text" id="city" name="city" value="<?php echo $ville; ?>" class="form-control"><br>
                <label for="age">Âge :</label><br>
                <input type="number" id="age" name="age" value="<?php echo $age; ?>" class="form-control"><br>
                <!-- Avatar Actuel -->
                <label for="avatar">Avatar actuel :</label><br>
                <img src="uploads/<?php echo $avatar_actuel; ?>" alt="Avatar actuel" width="100"><br><br>

                <!-- Nouvel Avatar -->
                <label for="avatar">Nouvel avatar :</label><br>
                <input type="file" id="avatar" name="avatar"><br><br>

                <button type="submit"
                onclick="return confirm('Voulez-vous vraiment modifier cet employé ?');"
                class="d-grid gap-2 col-12 mx-auto btn btn-warning">Confirmer</button>           
             </form>
        </div>
    </div>
</body>
</html>